//
//  ButtonAnimations.swift
//  Animatify
//
//  Created by Shubham Singh on 14/06/20.
//  Copyright © 2020 Shubham Singh. All rights reserved.
//

import UIKit
/*
 TODO - Add button animations here
 */
